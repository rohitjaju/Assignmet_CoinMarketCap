package utils;

import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;


import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;



public class Assignment2 {

									//====================Scenarios May 22================================

	//get hubs from organization A
	@Test
	public void getHubsFromOrgA() {
		 given().
	    when().
	    	get("").
	    then().
	    assertThat().
	    	contentType(ContentType.JSON).statusCode(200);
	    //body("places[0].'place name'", equalTo("Beverly Hills")).log().all();
	    throw new io.cucumber.java.PendingException();
		}


	//get Fleets from Hub B and organization A
	@Test
	public void getFleetsFromHubBOrgA() {
		 given().
	    when().
	    //From Hub B url	
	    get("").
	    then().
	    assertThat().
	    	contentType(ContentType.JSON).statusCode(200);
		 
		 given().when().
		//From OrgA url
		 get("").
	 		then().
	 		assertThat().
	 	contentType(ContentType.JSON).statusCode(200);
	    //body("places[0].'place name'", equalTo("Beverly Hills")).log().all();
	    throw new io.cucumber.java.PendingException();
		}

	// Automation code for the bearer token given. Provide beared tiken in "bearerToken" variable abd "url" in get method
	Response response =given()
	    .headers(
	        "Authorization",
	        "Bearer " + bearerToken,
	        "Content-Type",
	        ContentType.JSON,
	        "Accept",
	        ContentType.JSON)
	    .when()
	    .get(url)
	    .then()
	    .contentType(ContentType.JSON)
	    .extract()
	    .response();

	}



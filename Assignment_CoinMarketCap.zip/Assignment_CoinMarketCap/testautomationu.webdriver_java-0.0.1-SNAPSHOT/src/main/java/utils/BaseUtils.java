package utils;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class BaseUtils {
	
	public WebDriver driver;
	public static ExtentReports extent;
	
	public static ExtentTest scenarioDef;
	public static ExtentTest features;
	static String  reportLocation = "src/main/java/utils/";

	

}

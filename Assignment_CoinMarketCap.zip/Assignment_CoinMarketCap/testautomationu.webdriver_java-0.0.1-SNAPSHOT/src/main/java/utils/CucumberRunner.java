
package utils;

import io.cucumber.testng.CucumberOptions;
import java.io.File;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import com.cucumber.listener.Reporter;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.WindowManager;


@CucumberOptions(
		glue = {"src\\test\\java\\Login\\Login"}, 
		plugin = {"html:target/cucumber-reports/cucumber-pretty","json:target/cucumber.json",
"testng:target/testng-cucumber-reports/cuketestng.xml"},
		features = {"src/main/java/utils/Sample.feature"},
		monochrome= true)

public class CucumberRunner {
	//extends AbstractTestNGCucumberTests
	
	/*public static void writeExtentReport() {
		System.out.println(WindowManager.getReportConfigPath().toString());
		 Reporter.loadXMLConfig("configs/extent-config.xml");
		 }*/
	
}		 

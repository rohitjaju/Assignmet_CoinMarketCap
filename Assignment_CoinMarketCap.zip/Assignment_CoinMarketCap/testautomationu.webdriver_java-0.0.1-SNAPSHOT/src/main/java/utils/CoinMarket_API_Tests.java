package utils;

import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;


//import io.cucumber.datatable.DataTable;
import static io.restassured.RestAssured.given;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;

public class CoinMarket_API_Tests {
	private Response response;	

		
// Assignments
protected String api_key = "ecb60908-1a07-4ede-ab3b-b5c7adf9c704";

@Test
@When("^User validates coin market api$")
public void user_hit_the_CS_webservices() {
 given().
 	header("X-CMC_PRO_API_KEY",api_key).
 when().
 	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest").
 then().log().body();
 
 given().
	header("X-CMC_PRO_API_KEY",api_key).
when().
	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/listings/latest").
then().
 assertThat().
 	contentType(ContentType.JSON).statusCode(200);
 	
 
}

@Test
@When("^User validates the map call$")
public void backEndTask1_scenario1_retrieveIds() {
	String id =
	given().
 	header("X-CMC_PRO_API_KEY",api_key).
 when().
 	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/map").
 	then().
 	extract().
 		path("data.id").toString();
	System.out.println(id);
	
	String symbol =
			given().
		 	header("X-CMC_PRO_API_KEY",api_key).
		 when().
		 	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/map").
		 	then().
		 	extract().
		 		path("data.symbol").toString();
			 System.out.println(symbol);
}

@Test
@When("^User converts by price conversion call$")
public void backEndTask1_scenario2_priceConversion() {
	given().
 	header("X-CMC_PRO_API_KEY",api_key).
 when().
 	get("https://sandbox-api.coinmarketcap.com/v1/tools/price-conversion"). //Note: API doesn't not returns any values(Please confirm)
 then().log().body();
 
}
@Test
@When("^User validates the info call$")
public void backEndTask2_scenario1_retrieveEtheriumID() {
	
	given().
 	header("X-CMC_PRO_API_KEY",api_key).
 when().
 	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/info").//Note: API doesn't not returns any values(Please confirm)
 then().log().body();
		
}


@Test
@When("^User hit the info call an retrieves 10 currencies$")
public void backEndTask3_scenario1_retrieveCurrencies() {
	
	given().
 	header("X-CMC_PRO_API_KEY",api_key).
 when().
 	get("https://sandbox-api.coinmarketcap.com/v1/cryptocurrency/info"). //Note: API doesn't not returns any values(Please confirm)
 then().log().body();
		
	}	

}









package runner;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.gherkin.model.Feature;

import utils.ExtentReportsUtil;
import static utils.BaseUtils.features;

import java.io.IOException;

public class NGTestListener implements ITestListener{
	
	ExtentReportsUtil extentReportUtil = new ExtentReportsUtil();
	
	@Override
	public void onTestStart(ITestResult iTestResult) {
		System.out.println("On Test Start");
	}
	
	@Override
	public void onTestSuccess(ITestResult iTestResult) {
		System.out.println("On Test Success");
	}
	
	@Override
	public void onTestFailure(ITestResult iTestResult) {
		
		System.out.println("On Test Failure");
		
		//Take Screenshot for Failed Tests
		try {
				extentReportUtil.ExtentReportScreenshot();
		}	
		catch (IOException e){
				e.printStackTrace();
		}
	}
	
	public void onSkip(ITestResult iTestResult) {
		System.out.println("On Test Skipped");           
	}

	@Override
	public void onStart(ITestContext iTestContext) {
		System.out.println("On Start");
		
		//reports
		extentReportUtil.ExtentReport();
		
		//features- Hardcoded
		features= ExtentReportsUtil.extent.createTest(Feature.class,"Smaple");
	}
	
	@Override
	public void onFinish(ITestContext iTestContext) {
		System.out.println("On Finish");
		extentReportUtil.FlushReport();
	}
	
	
	
}

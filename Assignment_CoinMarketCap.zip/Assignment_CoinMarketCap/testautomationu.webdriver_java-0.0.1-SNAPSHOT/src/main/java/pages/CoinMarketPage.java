package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class CoinMarketPage {
	private WebDriver driver;
	public By show_rows = By.xpath("//*[@id=\"__next\"]/div/div[1]/div[2]/div/div[1]/div[3]/div[2]/div[3]/div[1]/div");
	public By show_rows_value1 = By.xpath("//button[contains(text(),'100')]");
	public By rows_displayed = By.xpath("//tr[100]//td//p[contains(text(),'100')]");
	public By rows_displayed_count_label = By.xpath("//p[contains(text(),'Showing 1 - 100 out of')]");
	
	public By filters = By.xpath("//*[@id=\"__next\"]/div/div[1]/div[2]/div/div[1]/div[3]/div[2]/div[3]/div[2]/button[1]");
	public By add_filters = By.xpath("//*[@id=\"__next\"]/div/div[1]/div[2]/div/div[1]/ul/li[5]/button");
	public By applied_filters_check = By.xpath("//*[@id='__next']/div/div[1]/div[2]/div/div[1]/ul/li[5]/button");
	public By filters_marketcap = By.xpath("//button[contains(text(),'Market Cap')]");
	public By filters_marketcap_range1 = By.xpath("//button[contains(text(),'$1B - $10B')]");
	
	public By filters_price = By.xpath("//button[contains(text(),'Price')]");
	public By filters_price_range1 = By.xpath("//button[contains(text(),'$101 - $1,000')]");
	public By apply_filters = By.xpath("//button[contains(text(),'Apply Filter')]");
	
	public By show_results_filters = By.xpath("//button[contains(text(),'Show results')]");
	
	

	
	public CoinMarketPage(WebDriver driver){
		this.driver=driver;
	}
	
	public void user_selects_show_rows() throws InterruptedException {
		driver.findElement(show_rows).click();
		driver.findElement(show_rows).click();
		driver.findElement(show_rows_value1).click();
		Thread.sleep(3000);
	}
	
	public boolean validateShowRowLabelCount() {
		return driver.findElement(rows_displayed_count_label).isDisplayed();
	}
	
	public void validateFilters() throws InterruptedException {
		driver.findElement(filters).click();
		Thread.sleep(2000);
		driver.findElement(add_filters).click();
		Thread.sleep(1000);
		
		driver.findElement(filters_marketcap).click();
		Thread.sleep(1000);
		driver.findElement(filters_marketcap_range1).click();
		Thread.sleep(1000);
		driver.findElement(apply_filters).click();
		
		driver.findElement(filters_price).click();
		Thread.sleep(1000);
		driver.findElement(filters_price_range1).click();
		Thread.sleep(2000);
		driver.findElement(apply_filters).click();
		
		driver.findElement(show_results_filters).click();
		Thread.sleep(1000);
	}
	
	public boolean validateappliedFilters() {
			return driver.findElement(applied_filters_check).isDisplayed();
		}
		
		
	}
	
	

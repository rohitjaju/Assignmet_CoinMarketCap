package Login;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.GherkinKeyword;

import base.BaseTests;
import io.cucumber.core.gherkin.ScenarioDefinition;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.SecureAreaPage;
import utils.BaseUtils;


public class LoginTests extends BaseTests{
//public class LoginTests extends BaseUtils{
	
	/*private BaseUtils base;
	
	 public LoginTests(BaseUtils base) {
		this.base = base;
	}
	*/
	
 @Test
	@When("User hit the Login")
	public void testLogin() throws ClassNotFoundException {
		/*scenarioDef.createNode(new GherkinKeyword("When"),"User hit the Login");
		base.driver.navigate().to("www.amazon.in");
		Assert.assertEquals(base.driver.getTitle().toString(), "Google");   */
	 
		LoginPage loginPage = homePage.clickFormAuthentication();
		loginPage.setUserName("tomsmith");
		loginPage.setPassword("SuperSecretPassword!");
		SecureAreaPage secureAreaPage = loginPage.clickLoginButton();
		Assert.assertTrue(secureAreaPage.getAlertText().contains("You logged into a secure area!"), "Alert message successfull");
		validateWindow();
		//You logged into a secure area!
	
 }	
		@Test
		void testSelectoption() {
			String option ="Option 1";
			var dropDownPage = homePage.clickDropdown();
			dropDownPage.selectFromDropDown(option);
			var selectedOptions = dropDownPage.getSelectedOptions();
			assertEquals(selectedOptions.size(),1, "Incorrect number of selections");
			assertTrue(selectedOptions.contains(option), "Option not selected");			
		
	}

}

package Login;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTests;
import io.cucumber.java.en.When;
import pages.CoinMarketPage;
import pages.LoginPage;
import pages.SecureAreaPage;
import pages.CoinMarketPage;;

public class CoinMarket_LoginPage_Tests extends BaseTests{		
	
 @Test
	public void testCoinMarketHome() throws ClassNotFoundException, InterruptedException {
	 CoinMarketPage CoinMarket_Login = new CoinMarketPage(driver);
	  CoinMarket_Login.user_selects_show_rows();
	  Assert.assertTrue(CoinMarket_Login.validateShowRowLabelCount(), "100 rows count label displayed successfully");	 
	}	
 
 @Test
	public void testCoinMarketFilters() throws ClassNotFoundException, InterruptedException {
	  CoinMarketPage CoinMarket_Login = new CoinMarketPage(driver);
	  CoinMarket_Login.validateFilters();
	  Assert.assertTrue(CoinMarket_Login.validateappliedFilters(), "2 Filters applied successfully");
	}	
 
}
